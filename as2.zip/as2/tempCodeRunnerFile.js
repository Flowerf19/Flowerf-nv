const express = require('express')
const app = express()
const port = 3000
const url = "mongodb+srv://Flowerf12:Flowerf12@database1.0pwmbke.mongodb.net/test"
const MongoClient = require('mongodb').MongoClient;


async function add(name, picture, style, price, amount) {
    let client = await MongoClient.connect(url)
    let dbo = client.db("Asm2Database");
    return await dbo
        .collection("asm2Database")
        .insertOne({ name: name, picture: picture, style: style, price: price, amount: amount, })
}
app.set('view engine', 'hbs')
app.use(express.urlencoded({ extended: true }))

app.get('/', (req, res) => res.render('home'));
app.listen(port, () => console.log(`Website listening on port ${port}!`));

app.get('/viewAll', async (req, res) => {
    const allToys = await allProduct();
    res.render("allToys", { allToys: allToys });
});
async function allProduct() {
    let client = await MongoClient.connect(url);
    let dbo = client.db("Asm2Database");
    return await dbo.collection("asm2Database").find({}).toArray();
};
app.get('/add', (req, res) => res.render('addNewToy'));
app.post('/add', async (req, res) => {
    console.log(req.body);
    const name = req.body.name;
    const picture = req.body.picture;
    const style = req.body.style;
    const price = req.body.price;
    const amount = req.body.amount;
    await add(name, picture, style, price, amount);
    res.redirect('/viewAll');
});
app.get('/delete/:id', async (req, res) => {
    const id = req.params.id
    await deleteProduct(id)
    res.redirect('/viewAll');
})
async function deleteProduct(id) {
    let client = await MongoClient.connect(url);
    let dbo = client.db("Asm2Database");
    const ObjectId = require('mongodb').ObjectId
    return await dbo.collection("asm2Database").deleteOne({ _id: new ObjectId(id) });
};
app.get('/forBoys', async (req, res) => {
    const toyForBoy = await byBoyStyle('For Boys');
    res.render('forBoy', { allToys: toyForBoy });
});

async function byBoyStyle(style) {
    let client = await MongoClient.connect(url);
    let dbo = client.db('Asm2Database');
    return await dbo.collection('asm2Database').find({ style: style }).toArray();
}
app.get('/forGirls', async (req, res) => {
    const toyForGirl = await byGirlStyle('For Girls');
    res.render('forGirl', { allToys: toyForGirl });
});
async function byGirlStyle(style) {
    let client = await MongoClient.connect(url);
    let dbo = client.db('Asm2Database');
    return await dbo.collection('asm2Database').find({ style: style }).toArray();
}
