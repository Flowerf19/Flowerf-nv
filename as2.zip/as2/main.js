const express = require('express')
const app = express()
const port = 3000
const url = "mongodb+srv://Flowerf12:Flowerf12@database1.0pwmbke.mongodb.net/test"
const MongoClient = require('mongodb').MongoClient;

const hbs = require('hbs');

app.set('view engine', 'hbs')
app.use(express.urlencoded({ extended: true }))

app.get('/', (req, res) => res.render('home'));
app.listen(port, () => console.log(`Website listening on port ${port}!`));

app.get('/viewAll', async (req, res) => {
    const allToys = await allProduct();
    res.render("allToys", { allToys: allToys });
});
async function allProduct() {
    let client = await MongoClient.connect(url);
    let dbo = client.db("Asm2Database");
    return await dbo.collection("asm2Database").find({}).toArray();
};
app.get('/add', (req, res) => res.render('addNewToy'));
app.post('/add', async (req, res) => {
    console.log(req.body);
    const name = req.body.name;
    const picture = req.body.picture;
    const style = req.body.style;
    const price = Number.parseFloat(req.body.price);
    const amount = Number.parseInt(req.body.amount);
    if (name.length < 5) {
        res.render('addNewToy', { nameError: 'The name must be at least 5 characters' })
        return;
    }
    const http = picture.substring(0, 7);
    const https = picture.substring(0, 8);
    if (!(http === 'http://') && !(https === 'https://')) {
        res.render('addNewToy', { pictureError: 'The url must be http or https!' });
    }
    await add(name, picture, style, price, amount);
    res.redirect('/viewAll');
});
async function add(name, picture, style, price, amount) {
    let client = await MongoClient.connect(url)
    let dbo = client.db("Asm2Database");
    return await dbo
        .collection("asm2Database")
        .insertOne({ name: name, picture: picture, style: style, price: price, amount: amount, })
}
app.get('/delete/:id', async (req, res) => {
    const id = req.params.id
    await deleteProduct(id)
    res.redirect('/viewAll');
})
async function deleteProduct(id) {
    let client = await MongoClient.connect(url);
    let dbo = client.db("Asm2Database");
    const ObjectId = require('mongodb').ObjectId
    return await dbo.collection("asm2Database").deleteOne({ _id: new ObjectId(id) });
};
app.get('/forBoys', async (req, res) => {
    const toyForBoy = await byBoyStyle('For Boys');
    res.render('forBoy', { allToys: toyForBoy });
});

async function byBoyStyle(style) {
    let client = await MongoClient.connect(url);
    let dbo = client.db('Asm2Database');
    return await dbo.collection('asm2Database').find({ style: style }).toArray();
}
app.get('/forGirls', async (req, res) => {
    const toyForGirl = await byGirlStyle('For Girls');
    res.render('forGirl', { allToys: toyForGirl });
});
async function byGirlStyle(style) {
    let client = await MongoClient.connect(url);
    let dbo = client.db('Asm2Database');
    return await dbo.collection('asm2Database').find({ style: style }).toArray();
}

app.get('/edit/:id', async (req, res) => {
    const id = req.params.id;
    let client = await MongoClient.connect(url);
    let dbo = client.db("Asm2Database");
    const ObjectId = require('mongodb').ObjectId;
    const toy = await dbo.collection("asm2Database").findOne({ _id: new ObjectId(id) });
    res.render('editToy', { toy: toy });
});

app.post('/edit/:id', async (req, res) => {
    const id = req.params.id;
    const name = req.body.name;
    const picture = req.body.picture;
    const style = req.body.style;
    const price = Number.parseFloat(req.body.price);
    const amount = Number.parseInt(req.body.amount);
    console.log(price);
    if (name.length < 5) {
        res.render('editToy', { nameError: 'The name must be at least 5 characters', toy: { _id: id, name: name, picture: picture, style: style, price: price, amount: amount } })
        return;
    }
    if (price < 0) {
        console.log(price);
        res.render('editToy', {priceError: 'You must provide a price', toy: { _id: id, name: name, picture: picture, style: style, price: price, amount: amount } })
        return;
    }
    const http = picture.substring(0, 7);
    const https = picture.substring(0, 8);
    if (!(http === 'http://') && !(https === 'https://')) {
        res.render('editToy', { pictureError: 'The url must be http or https!', toy: { _id: id, name: name, picture: picture, style: style, price: price, amount: amount } });
        return;
    }
    let client = await MongoClient.connect(url)
    let dbo = client.db("Asm2Database");
    const ObjectId = require('mongodb').ObjectId;
    await dbo.collection("asm2Database").updateOne({ _id: new ObjectId(id) }, { $set: { name: name, picture: picture, style: style, price: price, amount: amount } });
    res.redirect('/viewAll');
});

// register helper function
hbs.registerHelper("checkPrice", function(price) {
    if (price < 0) {
      return true;
    }
    return false;
  });